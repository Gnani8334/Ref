package com.cg.product.service;

import java.util.ArrayList;

import com.cg.product.exception.ProductException;
import com.cg.product.model.Product;

public interface IProductService {

	 public  ArrayList<Product> getDetails() throws ProductException;

	public String findName() throws ProductException;

}
