package com.cg.product.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.IProductDAO;
import com.cg.product.exception.ProductException;
import com.cg.product.model.Product;
@Service
public class ProductServiceImpl implements IProductService {
@Autowired
IProductDAO daoImp;
	@Override
	public ArrayList<Product> getDetails() throws ProductException{
		// TODO Auto-generated method stub
		return daoImp.getDetails();
	}
	@Override
	public String findName() throws ProductException{
		// TODO Auto-generated method stub
		return daoImp.findName();
	}

}
