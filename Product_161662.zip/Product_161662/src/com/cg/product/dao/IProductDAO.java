package com.cg.product.dao;

import java.util.ArrayList;

import com.cg.product.exception.ProductException;
import com.cg.product.model.Product;

public interface IProductDAO {

	 public ArrayList<Product> getDetails() throws ProductException;

	public String findName() throws ProductException;

}
