package com.cg.product.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.product.exception.ProductException;
import com.cg.product.model.Product;
@Repository
public class ProductDAOImpl implements IProductDAO {
@PersistenceContext
EntityManager em;
	@Override
	public ArrayList<Product> getDetails() throws ProductException{
		// TODO Auto-generated method stub
		
		Query qry=em.createNamedQuery("q1");
	List<Product> productDetails=	qry.getResultList();
		
	return (ArrayList<Product>) productDetails;

	
		
	}
	@Override
	public String findName() throws ProductException{
		Query qry=em.createNamedQuery("q2");
		// TODO Auto-generated method stub
		
		return (String) qry.getSingleResult();
	}

}
