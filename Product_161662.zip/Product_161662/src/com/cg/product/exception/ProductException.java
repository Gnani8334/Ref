package com.cg.product.exception;

public class ProductException extends Exception
{
	private static final long serialVersionUID = 1L;
	 private String msg="Product details not found";
	 public ProductException(String msg) {
		 this.msg = msg;
	 }
	
}
