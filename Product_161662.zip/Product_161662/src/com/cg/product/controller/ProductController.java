package com.cg.product.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.product.exception.ProductException;
import com.cg.product.model.Product;
import com.cg.product.service.IProductService;

@Controller
public class ProductController {
	@Autowired
	IProductService service;
	@RequestMapping("home")
	public String getDetails(Model model) 
	{
		ArrayList<Product> pDetails = null;
		
			try {
				pDetails = service.getDetails();
			} catch (ProductException e) {
				// TODO Auto-generated catch block
				System.out.println("Product Details Not found");
			}
		model.addAttribute(pDetails);
		String view="productdetails";
				return view;
	}
	@RequestMapping("booking")
	public String display(Model model) throws ProductException
	{
		String name=service.findName();
		model.addAttribute(name);
		String view="bookingdetails";
		return view;
	}
	

}
