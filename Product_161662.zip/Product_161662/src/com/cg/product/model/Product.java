package com.cg.product.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="product_details")
@NamedQueries(
		{
@NamedQuery(name="q1",query="select product from Product_details product"),
@NamedQuery(name="q2",query="select name from Product_details product where id=:id")
		})
public class Product {
	@Id
@GeneratedValue(strategy=GenerationType.AUTO)	
private Integer id;
private String name;
private Double price;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Double getPrice() {
	return price;
}
public void setPrice(Double price) {
	this.price = price;
}
public Product(Integer id, String name, Double price) {
	super();
	this.id = id;
	this.name = name;
	this.price = price;
}
public Product()
{
}
}


