package com.capgemini.service;

public interface ICustomerService {
private void addCustomer(Customer customer) extends CustomerException; 
}
