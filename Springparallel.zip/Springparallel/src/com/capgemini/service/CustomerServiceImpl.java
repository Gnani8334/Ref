package com.capgemini.service;

import com.capgemini.model.Customer;

public class CustomerServiceImpl implements ICustomerService {

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}


	

}
