
package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.exception.CustomerException;
import com.capgemini.model.Customer;
import com.capgemini.service.ICustomerService;
@Controller
public class BankController {
	@Autowired
	Customer customer;
	ICustomerService customerService;
	@RequestMapping(value="/register" ,method=RequestMethod.GET)
	public ModelAndView customerForm() {
		
		return new ModelAndView("customerregistration","customer",customer);
	}
	@RequestMapping(value="/register" ,method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute(value="customer")Customer customer) {
		//System.out.println(customer.getCustomerName());
		try {
			String status=customerService.addCustomer(customer);
			return new ModelAndView("cust_status","message",status);
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
	}

}
