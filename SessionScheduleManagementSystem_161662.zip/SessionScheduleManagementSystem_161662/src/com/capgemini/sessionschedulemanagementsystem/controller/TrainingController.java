package com.capgemini.sessionschedulemanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.sessionschedulemanagementsystem.exception.SessionDetailsNotFoundException;
import com.capgemini.sessionschedulemanagementsystem.model.Client;
import com.capgemini.sessionschedulemanagementsystem.service.ITrainingService;

@Controller
public class TrainingController {
	@Autowired
	ITrainingService clientService; // autowired creates the objects for service layer
	@RequestMapping(value="home")
	public ModelAndView getAllSessionDetails() throws SessionDetailsNotFoundException {
	
			List<Client> clientList = null;
			try {
				clientList = clientService.getAllSessionDetails();
			} catch (SessionDetailsNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("session details not found");
			}
						
				return new ModelAndView("ScheduledSessions","sessionList",clientList);//sessionList is the model object and ScheduledSessions is the view page
			
				}
	@RequestMapping("name") 
	public String findSessionName(Model model) 
	{
		String SessionName=null;
		try {
			SessionName = clientService.findSessionName();//calling the service method 
		} catch (SessionDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("session name not found");
		}
		model.addAttribute(SessionName);//adding the data to the model attribute
		String view="Success";
		return view;// returning the view
	}
}
