package com.capgemini.sessionschedulemanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.sessionschedulemanagementsystem.dao.ITrainingDAO;
import com.capgemini.sessionschedulemanagementsystem.exception.SessionDetailsNotFoundException;
import com.capgemini.sessionschedulemanagementsystem.model.Client;
@Service
public class TrainingServiceImpl  implements ITrainingService{
	@Autowired
	private ITrainingDAO clientDAOImp;//autowired creates the objects for daoImplementation 
	@Override
	public List<Client> getAllSessionDetails() throws SessionDetailsNotFoundException{
		// TODO Auto-generated method stub
		return clientDAOImp.getAllSessionDetails();//calling the dao method to get the session details 
	}
	@Override
	public String findSessionName() throws SessionDetailsNotFoundException {
		// TODO Auto-generated method stub
		return clientDAOImp.findSessionName();//calling the dao method to get the session name 
	}

}
