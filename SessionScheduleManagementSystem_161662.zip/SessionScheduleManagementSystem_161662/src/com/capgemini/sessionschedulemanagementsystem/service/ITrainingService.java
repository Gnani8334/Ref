package com.capgemini.sessionschedulemanagementsystem.service;

import java.util.List;

import com.capgemini.sessionschedulemanagementsystem.exception.SessionDetailsNotFoundException;
import com.capgemini.sessionschedulemanagementsystem.model.Client;

public interface ITrainingService {

public	List<Client> getAllSessionDetails() throws SessionDetailsNotFoundException;

public String findSessionName() throws SessionDetailsNotFoundException;

}
