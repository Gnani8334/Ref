package com.capgemini.sessionschedulemanagementsystem.exception;

public class SessionDetailsNotFoundException extends Exception{
  /**
	 * @Created by:Gnaneswari
 * created on:11/19/2018
 * Class description:ExceptionClass
	 */
	private static final long serialVersionUID = 1L;
String message;
  public SessionDetailsNotFoundException()
  {
	  
  }

public SessionDetailsNotFoundException(String message) {
	super();
	this.message = message;
}
}
