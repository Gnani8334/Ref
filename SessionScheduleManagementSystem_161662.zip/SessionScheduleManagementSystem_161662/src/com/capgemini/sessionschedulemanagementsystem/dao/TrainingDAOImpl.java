package com.capgemini.sessionschedulemanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.sessionschedulemanagementsystem.exception.SessionDetailsNotFoundException;
import com.capgemini.sessionschedulemanagementsystem.model.Client;
@Repository
public class TrainingDAOImpl  implements ITrainingDAO{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<Client>getAllSessionDetails() throws SessionDetailsNotFoundException {
		// TODO Auto-generated method stub

		Query query=entityManager.createNamedQuery("q1");//q1 is the named query defined in query class 
	List<Client> sessionDetails=query.getResultList();
		
	return (ArrayList<Client>) sessionDetails;
	}
	@Override
	public String findSessionName() throws SessionDetailsNotFoundException {
		Query query=entityManager.createNamedQuery("q2");//q2 is the named query defined in query class 
		// TODO Auto-generated method stub
		String sessionname=(String) query.getSingleResult();
		return sessionname;//returning the sessionname to the service
		
		
	}

}
