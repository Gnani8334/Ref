package com.capgemini.sessionschedulemanagementsystem.dao;

import java.util.List;

import com.capgemini.sessionschedulemanagementsystem.exception.SessionDetailsNotFoundException;
import com.capgemini.sessionschedulemanagementsystem.model.Client;

public interface ITrainingDAO {

public	List<Client> getAllSessionDetails() throws SessionDetailsNotFoundException;

public String findSessionName() throws SessionDetailsNotFoundException;

}
