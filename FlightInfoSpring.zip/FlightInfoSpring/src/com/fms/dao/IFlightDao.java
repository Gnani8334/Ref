package com.fms.dao;

import java.util.ArrayList;

import com.fms.bean.FlightBean;

public interface IFlightDao {
	public ArrayList<FlightBean> getAllFlightInfo();
}
