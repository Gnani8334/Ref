package com.fms.service;

import java.util.ArrayList;

import com.fms.bean.FlightBean;

public interface IFlightService {

		public ArrayList<FlightBean> getAllFlightInfo();
	
	
}
