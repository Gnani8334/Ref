package com.capgemini.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;


@Component
public class Customer {
	private Integer accountNumber=(int)(((Math.random())*10000)+19898);
	
	private Integer pin=(int)(((Math.random())*1000)+1989);;
	private String accountHolderName;
	@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date birthdate;
	private Long mobileNumber;
	private String address;
	private String emailId;
	public Customer()
	{
		
	}
	public Customer(Integer accountNumber, Integer pin,
			String accountHolderName, Date birthdate, Long mobileNumber,
			String address, String emailId) {
		super();
		this.accountNumber = accountNumber;
		this.pin = pin;
		this.accountHolderName = accountHolderName;
		this.birthdate = birthdate;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.emailId = emailId;
	}
	public Integer getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(Integer pin) {
		this.pin = pin;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "Customer [accountNumber=" + accountNumber + ", pin=" + pin
				+ ", accountHolderName=" + accountHolderName + ", birthdate="
				+ birthdate + ", mobileNumber=" + mobileNumber + ", address="
				+ address + ", emailId=" + emailId + "]";
	}
	
	
	
	
}
