package com.capgemini.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="customer_details")
public class CustomerEntity {
	@Id
	@Column(name="	AccountNumber")
	@SequenceGenerator(name="cust_jpa_seq_sg", sequenceName="customer_details_seq",allocationSize=1)
	@GeneratedValue(generator="cust_jpa_seq_sg", strategy=GenerationType.SEQUENCE)
	private Integer accountnumber;
	@Column(name="AccountHolderName")
	private String AccountHolderName;
	@Temporal(TemporalType.DATE)
	private Date birthdate;
	private Long mobileNumber;
	private String address;
	private String emailId;
	
	
	public Integer getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(Integer accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getCustomerName() {
		return AccountHolderName ;
	}
	public void setCustomerName(String customerName) {
		this.AccountHolderName = customerName;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	
	public String getCustomizedBirthdate() {
		SimpleDateFormat dateFormat=
						new SimpleDateFormat("dd-MM-yyyy");
		String sdate=dateFormat.format(this.birthdate);
		return sdate;
	}
	
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAccountHolderName() {
		return AccountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		AccountHolderName = accountHolderName;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	
}
