package com.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.CustomerEntity;
import com.capgemini.exception.CustomerException;
import com.capgemini.utility.AppConfig;
@Repository
public class CustomerServiceDAOImpl implements ICustomerServiceDAO{
@PersistenceContext
EntityManager entityManager;

	

	@Override
	public String addCustomer(CustomerEntity customer)
			throws CustomerException {
		Logger myLogger=Logger.getLogger(CustomerServiceDAOImpl.class);
		try {
			entityManager.persist(customer);
			myLogger.info(AppConfig.PROPERTIES.getProperty("CUSTOMER_INSERT.SUCCESS"));
			return AppConfig.PROPERTIES.getProperty("CUSTOMER_INSERT.SUCCESS");
		}catch(PersistenceException e) {
			throw new CustomerException(e.getMessage());
		}
	}

}
