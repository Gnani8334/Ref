package com.capgemini.dao;

import com.capgemini.entity.CustomerEntity;
import com.capgemini.exception.CustomerException;
import com.capgemini.model.Customer;

public interface ICustomerServiceDAO {
	public String addCustomer(CustomerEntity customerEntity) throws CustomerException; 

}
