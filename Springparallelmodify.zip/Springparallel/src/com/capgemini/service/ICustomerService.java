package com.capgemini.service;

import com.capgemini.exception.CustomerException;
import com.capgemini.model.Customer;

public interface ICustomerService {
public String addCustomer(Customer customer) throws CustomerException; 
}
