package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.ICustomerServiceDAO;
import com.capgemini.entity.CustomerEntity;
import com.capgemini.exception.CustomerException;
import com.capgemini.model.Customer;
@Service
public class CustomerServiceImpl implements ICustomerService {
@Autowired
ICustomerServiceDAO customerDao;
	@Override
	public String addCustomer(Customer customer) throws CustomerException {
		CustomerValidator validator=new CustomerValidator();
		if(validator.validate(customer)) {			
			CustomerEntity customerEntity=new CustomerEntity();
			populateCustomerEntity(customer,customerEntity);
			String  status=customerDao.addCustomer(customerEntity);
			return status;
		}else {
			return "Invalid Customer Details";
		}
		
		// TODO Auto-generated method stub
		
	}
	private void populateCustomerEntity(Customer customer, CustomerEntity customerEntity) {
		customerEntity.setAccountnumber(customer.getAccountNumber());
		customerEntity.setCustomerName(customer.getAccountHolderName());
		customerEntity.setMobileNumber(customer.getMobileNumber());
		customerEntity.setAddress(customer.getAddress());
		customerEntity.setEmailId(customer.getEmailId());
		customerEntity.setBirthdate(customer.getBirthdate());
	}


	

}
