package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;

public interface IDoctorAppointmentDao {
int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);
DoctorAppointment  getDoctorAppointmentDetails(int appointmentId)throws DrSmartException;
}
