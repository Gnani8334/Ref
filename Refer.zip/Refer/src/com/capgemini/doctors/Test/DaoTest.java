package com.capgemini.doctors.Test;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.doctors.dao.DoctorAppointmentDao;

public class DaoTest {
	DoctorAppointmentDao doctorDao;

	@Before
	public void setUp() throws Exception {
		 doctorDao=new DoctorAppointmentDao();
	}

	@After
	public void tearDown() throws Exception {
		doctorDao=null;
	}

	@Test
	public void testAddDoctorAppointmentDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDoctorAppointmentDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatePatientDetails() {
		fail("Not yet implemented");
	}

}
